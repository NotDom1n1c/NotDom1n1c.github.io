@echo off
cd /d "%~dp0"
set CSC=C:\Windows\Microsoft.NET\Framework644.0.30319\csc.exe
"%CSC%" /nologo /target:winexe /optimize+ /out:MakroRekorder.exe /win32icon:makro.ico /reference:System.dll /reference:System.Drawing.dll /reference:System.Windows.Forms.dll MakroRekorder.cs
if errorlevel 1 (echo.& echo Fehler beim Kompilieren.) else (echo.& echo Fertig: MakroRekorder.exe)
pause
