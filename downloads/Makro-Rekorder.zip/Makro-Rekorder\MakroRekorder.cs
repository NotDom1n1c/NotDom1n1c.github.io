// MakroRekorder - nimmt Mausbewegungen, Klicks, Mausrad und Tastatur auf
// und spielt sie wieder ab. Mit Endlos-Wiederholung bis zum Stopp.
// Kompilieren: csc /target:winexe /out:MakroRekorder.exe MakroRekorder.cs

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;

namespace MakroRekorder
{
    [StructLayout(LayoutKind.Sequential)]
    public struct POINT { public int x; public int y; }

    [StructLayout(LayoutKind.Sequential)]
    public struct MSLLHOOKSTRUCT { public POINT pt; public uint mouseData; public uint flags; public uint time; public IntPtr dwExtraInfo; }

    [StructLayout(LayoutKind.Sequential)]
    public struct KBDLLHOOKSTRUCT { public uint vkCode; public uint scanCode; public uint flags; public uint time; public IntPtr dwExtraInfo; }

    [StructLayout(LayoutKind.Sequential)]
    public struct MOUSEINPUT { public int dx; public int dy; public uint mouseData; public uint dwFlags; public uint time; public IntPtr dwExtraInfo; }

    [StructLayout(LayoutKind.Sequential)]
    public struct KEYBDINPUT { public ushort wVk; public ushort wScan; public uint dwFlags; public uint time; public IntPtr dwExtraInfo; }

    [StructLayout(LayoutKind.Sequential)]
    public struct HARDWAREINPUT { public uint uMsg; public ushort wParamL; public ushort wParamH; }

    [StructLayout(LayoutKind.Explicit)]
    public struct INPUTUNION
    {
        [FieldOffset(0)] public MOUSEINPUT mi;
        [FieldOffset(0)] public KEYBDINPUT ki;
        [FieldOffset(0)] public HARDWAREINPUT hi;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct INPUT { public uint type; public INPUTUNION u; }

    internal static class Win
    {
        public delegate IntPtr HookProc(int nCode, IntPtr wParam, IntPtr lParam);

        [DllImport("user32.dll", SetLastError = true)]
        public static extern IntPtr SetWindowsHookEx(int idHook, HookProc lpfn, IntPtr hMod, uint dwThreadId);
        [DllImport("user32.dll", SetLastError = true)]
        public static extern bool UnhookWindowsHookEx(IntPtr hhk);
        [DllImport("user32.dll")]
        public static extern IntPtr CallNextHookEx(IntPtr hhk, int nCode, IntPtr wParam, IntPtr lParam);
        [DllImport("kernel32.dll", CharSet = CharSet.Auto)]
        public static extern IntPtr GetModuleHandle(string lpModuleName);
        [DllImport("user32.dll", SetLastError = true)]
        public static extern uint SendInput(uint nInputs, INPUT[] pInputs, int cbSize);
        [DllImport("user32.dll")]
        public static extern bool SetProcessDPIAware();
        [DllImport("user32.dll")]
        public static extern int GetSystemMetrics(int nIndex);
        [DllImport("user32.dll")]
        public static extern uint MapVirtualKey(uint uCode, uint uMapType);

        public const int WH_KEYBOARD_LL = 13;
        public const int WH_MOUSE_LL = 14;

        public const int WM_MOUSEMOVE = 0x0200;
        public const int WM_LBUTTONDOWN = 0x0201;
        public const int WM_LBUTTONUP = 0x0202;
        public const int WM_RBUTTONDOWN = 0x0204;
        public const int WM_RBUTTONUP = 0x0205;
        public const int WM_MBUTTONDOWN = 0x0207;
        public const int WM_MBUTTONUP = 0x0208;
        public const int WM_MOUSEWHEEL = 0x020A;
        public const int WM_XBUTTONDOWN = 0x020B;
        public const int WM_XBUTTONUP = 0x020C;
        public const int WM_MOUSEHWHEEL = 0x020E;

        public const int WM_KEYDOWN = 0x0100;
        public const int WM_KEYUP = 0x0101;
        public const int WM_SYSKEYDOWN = 0x0104;
        public const int WM_SYSKEYUP = 0x0105;

        public const uint LLMHF_INJECTED = 0x00000001;
        public const uint LLKHF_INJECTED = 0x00000010;

        public const uint MOUSEEVENTF_MOVE = 0x0001;
        public const uint MOUSEEVENTF_LEFTDOWN = 0x0002;
        public const uint MOUSEEVENTF_LEFTUP = 0x0004;
        public const uint MOUSEEVENTF_RIGHTDOWN = 0x0008;
        public const uint MOUSEEVENTF_RIGHTUP = 0x0010;
        public const uint MOUSEEVENTF_MIDDLEDOWN = 0x0020;
        public const uint MOUSEEVENTF_MIDDLEUP = 0x0040;
        public const uint MOUSEEVENTF_XDOWN = 0x0080;
        public const uint MOUSEEVENTF_XUP = 0x0100;
        public const uint MOUSEEVENTF_WHEEL = 0x0800;
        public const uint MOUSEEVENTF_HWHEEL = 0x1000;
        public const uint MOUSEEVENTF_VIRTUALDESK = 0x4000;
        public const uint MOUSEEVENTF_ABSOLUTE = 0x8000;

        public const uint KEYEVENTF_EXTENDEDKEY = 0x0001;
        public const uint KEYEVENTF_KEYUP = 0x0002;
        public const uint KEYEVENTF_SCANCODE = 0x0008;

        public const int SM_XVIRTUALSCREEN = 76;
        public const int SM_YVIRTUALSCREEN = 77;
        public const int SM_CXVIRTUALSCREEN = 78;
        public const int SM_CYVIRTUALSCREEN = 79;
    }

    // Ein einzelner aufgenommener Schritt
    public class Ev
    {
        public int Type;   // 0 Move, 1 MausRunter, 2 MausHoch, 3 Rad, 4 RadWaagrecht, 5 TasteRunter, 6 TasteHoch
        public long T;     // Millisekunden seit Aufnahmestart
        public int X;
        public int Y;
        public int Data;   // Maustaste / Raddrehung / Tastencode

        public const int MOVE = 0;
        public const int MDOWN = 1;
        public const int MUP = 2;
        public const int WHEEL = 3;
        public const int HWHEEL = 4;
        public const int KDOWN = 5;
        public const int KUP = 6;

        public const int BTN_L = 0;
        public const int BTN_R = 1;
        public const int BTN_M = 2;
        public const int BTN_X1 = 3;
        public const int BTN_X2 = 4;
    }

    public class MainForm : Form
    {
        // Zustand
        private List<Ev> events = new List<Ev>();
        private volatile bool recording = false;
        private volatile bool playing = false;
        private volatile bool stopRequested = false;
        private Stopwatch recClock = new Stopwatch();
        private Thread playThread = null;
        private volatile int currentRep = 0;

        // Hooks (Delegate muessen als Feld leben, sonst raeumt der GC sie weg)
        private Win.HookProc mouseProc;
        private Win.HookProc keyProc;
        private IntPtr hMouse = IntPtr.Zero;
        private IntPtr hKey = IntPtr.Zero;

        // Oberflaeche
        private Label lblStatus;
        private Label lblCount;
        private Button btnRec;
        private Button btnPlay;
        private Button btnClear;
        private Button btnSave;
        private Button btnLoad;
        private RadioButton rbCount;
        private RadioButton rbForever;
        private NumericUpDown numCount;
        private NumericUpDown numPause;
        private NumericUpDown numSpeed;
        private CheckBox chkMoves;
        private CheckBox chkTop;
        private System.Windows.Forms.Timer uiTimer;

        private static readonly Color BG = Color.FromArgb(24, 24, 28);
        private static readonly Color FG = Color.FromArgb(235, 235, 240);
        private static readonly Color DIM = Color.FromArgb(155, 155, 165);
        private static readonly Color ACC = Color.FromArgb(225, 70, 70);

        public MainForm()
        {
            BuildUi();
            InstallHooks();
        }

        // Skalierung fuer Windows-Anzeigeeinstellung (100 %, 125 %, 150 % ...)
        private float sc = 1f;
        private int S(int v) { return (int)Math.Round(v * sc); }

        private void Place(Control c, int x, int y, int w, int h)
        {
            c.Left = S(x); c.Top = S(y); c.Width = S(w);
            if (h > 0) c.Height = S(h);
        }

        private Label MkLabel(string text, int x, int y, int w, bool dim)
        {
            Label l = new Label();
            l.Text = text;
            Place(l, x, y, w, 22);
            l.ForeColor = dim ? DIM : FG;
            l.BackColor = Color.Transparent;
            return l;
        }

        private Button MkButton(string text, int x, int y, int w, int h)
        {
            Button b = new Button();
            b.Text = text;
            Place(b, x, y, w, h);
            b.FlatStyle = FlatStyle.Flat;
            b.FlatAppearance.BorderColor = Color.FromArgb(70, 70, 80);
            b.BackColor = Color.FromArgb(42, 42, 50);
            b.ForeColor = FG;
            b.UseVisualStyleBackColor = false;
            return b;
        }

        private void StyleNum(NumericUpDown n)
        {
            n.BackColor = Color.FromArgb(42, 42, 50);
            n.ForeColor = FG;
            n.BorderStyle = BorderStyle.FixedSingle;
        }

        private void BuildUi()
        {
            using (Graphics g = CreateGraphics()) { sc = g.DpiX / 96f; }
            if (sc < 1f) sc = 1f;

            Text = "Makro-Rekorder";
            AutoScaleMode = AutoScaleMode.None;
            ClientSize = new Size(S(480), S(500));
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            StartPosition = FormStartPosition.CenterScreen;
            BackColor = BG;
            ForeColor = FG;
            Font = new Font("Segoe UI", 10f);

            lblStatus = new Label();
            lblStatus.Text = "Bereit";
            Place(lblStatus, 20, 14, 440, 38);
            lblStatus.Font = new Font("Segoe UI", 16f, FontStyle.Bold);
            lblStatus.ForeColor = FG;
            Controls.Add(lblStatus);

            lblCount = MkLabel("0 Schritte", 20, 54, 440, true);
            Controls.Add(lblCount);

            btnRec = MkButton("Aufnehmen  (F9)", 20, 86, 214, 46);
            btnRec.Click += delegate { ToggleRecord(); };
            Controls.Add(btnRec);

            btnPlay = MkButton("Abspielen  (F10)", 246, 86, 214, 46);
            btnPlay.Click += delegate { TogglePlay(); };
            Controls.Add(btnPlay);

            GroupBox gb = new GroupBox();
            gb.Text = "Wiederholung";
            Place(gb, 20, 146, 440, 136);
            gb.ForeColor = DIM;
            Controls.Add(gb);

            rbCount = new RadioButton();
            rbCount.Text = "Anzahl Durchlaeufe:";
            Place(rbCount, 14, 28, 200, 28);
            rbCount.Checked = true;
            rbCount.ForeColor = FG;
            gb.Controls.Add(rbCount);

            numCount = new NumericUpDown();
            Place(numCount, 250, 28, 100, 0);
            numCount.Minimum = 1; numCount.Maximum = 1000000; numCount.Value = 1;
            StyleNum(numCount);
            gb.Controls.Add(numCount);

            rbForever = new RadioButton();
            rbForever.Text = "Endlos wiederholen, bis ich stoppe";
            Place(rbForever, 14, 60, 410, 28);
            rbForever.ForeColor = FG;
            gb.Controls.Add(rbForever);

            Label lp = MkLabel("Pause dazwischen (ms):", 14, 98, 230, true);
            lp.ForeColor = FG;
            gb.Controls.Add(lp);

            numPause = new NumericUpDown();
            Place(numPause, 250, 95, 100, 0);
            numPause.Minimum = 0; numPause.Maximum = 600000; numPause.Value = 0;
            numPause.Increment = 100;
            StyleNum(numPause);
            gb.Controls.Add(numPause);

            Label ls = MkLabel("Tempo (1 = normal, 2 = doppelt):", 20, 300, 250, false);
            Controls.Add(ls);

            numSpeed = new NumericUpDown();
            Place(numSpeed, 270, 297, 100, 0);
            numSpeed.DecimalPlaces = 2;
            numSpeed.Minimum = 0.1m; numSpeed.Maximum = 20m; numSpeed.Value = 1m;
            numSpeed.Increment = 0.25m;
            StyleNum(numSpeed);
            Controls.Add(numSpeed);

            chkMoves = new CheckBox();
            chkMoves.Text = "Mausbewegung aufnehmen (aus = nur Klicks)";
            Place(chkMoves, 20, 334, 440, 28);
            chkMoves.Checked = true;
            chkMoves.ForeColor = FG;
            Controls.Add(chkMoves);

            chkTop = new CheckBox();
            chkTop.Text = "Fenster immer im Vordergrund";
            Place(chkTop, 20, 364, 440, 28);
            chkTop.ForeColor = FG;
            chkTop.CheckedChanged += delegate { TopMost = chkTop.Checked; };
            Controls.Add(chkTop);

            btnClear = MkButton("Leeren", 20, 404, 140, 38);
            btnClear.Click += delegate { ClearEvents(); };
            Controls.Add(btnClear);

            btnSave = MkButton("Speichern", 170, 404, 140, 38);
            btnSave.Click += delegate { SaveMacro(); };
            Controls.Add(btnSave);

            btnLoad = MkButton("Laden", 320, 404, 140, 38);
            btnLoad.Click += delegate { LoadMacro(); };
            Controls.Add(btnLoad);

            Controls.Add(MkLabel("F9 = Aufnahme starten / stoppen", 20, 452, 440, true));
            Controls.Add(MkLabel("F10 = Abspielen starten / stoppen     Esc = Not-Stopp", 20, 474, 440, true));

            uiTimer = new System.Windows.Forms.Timer();
            uiTimer.Interval = 120;
            uiTimer.Tick += delegate { UpdateUi(); };
            uiTimer.Start();

            FormClosing += delegate { stopRequested = true; RemoveHooks(); };
        }

        // ---------------- Hooks ----------------

        private void InstallHooks()
        {
            mouseProc = new Win.HookProc(MouseHook);
            keyProc = new Win.HookProc(KeyHook);
            IntPtr mod = Win.GetModuleHandle(null);
            hMouse = Win.SetWindowsHookEx(Win.WH_MOUSE_LL, mouseProc, mod, 0);
            hKey = Win.SetWindowsHookEx(Win.WH_KEYBOARD_LL, keyProc, mod, 0);
            if (hMouse == IntPtr.Zero || hKey == IntPtr.Zero)
            {
                MessageBox.Show(this, "Die Eingabe-Hooks konnten nicht gesetzt werden. Bitte das Programm neu starten.",
                    "Makro-Rekorder", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void RemoveHooks()
        {
            if (hMouse != IntPtr.Zero) { Win.UnhookWindowsHookEx(hMouse); hMouse = IntPtr.Zero; }
            if (hKey != IntPtr.Zero) { Win.UnhookWindowsHookEx(hKey); hKey = IntPtr.Zero; }
        }

        private void Add(int type, int x, int y, int data)
        {
            Ev e = new Ev();
            e.Type = type;
            e.T = recClock.ElapsedMilliseconds;
            e.X = x; e.Y = y; e.Data = data;
            events.Add(e);
        }

        private static int HiWord(uint v) { return (int)((v >> 16) & 0xFFFF); }

        private IntPtr MouseHook(int nCode, IntPtr wParam, IntPtr lParam)
        {
            if (nCode >= 0 && recording)
            {
                MSLLHOOKSTRUCT m = (MSLLHOOKSTRUCT)Marshal.PtrToStructure(lParam, typeof(MSLLHOOKSTRUCT));
                if ((m.flags & Win.LLMHF_INJECTED) == 0)
                {
                    int msg = wParam.ToInt32();
                    int x = m.pt.x, y = m.pt.y;
                    switch (msg)
                    {
                        case Win.WM_MOUSEMOVE:
                            if (chkMoves.Checked) Add(Ev.MOVE, x, y, 0);
                            break;
                        case Win.WM_LBUTTONDOWN: Add(Ev.MDOWN, x, y, Ev.BTN_L); break;
                        case Win.WM_LBUTTONUP: Add(Ev.MUP, x, y, Ev.BTN_L); break;
                        case Win.WM_RBUTTONDOWN: Add(Ev.MDOWN, x, y, Ev.BTN_R); break;
                        case Win.WM_RBUTTONUP: Add(Ev.MUP, x, y, Ev.BTN_R); break;
                        case Win.WM_MBUTTONDOWN: Add(Ev.MDOWN, x, y, Ev.BTN_M); break;
                        case Win.WM_MBUTTONUP: Add(Ev.MUP, x, y, Ev.BTN_M); break;
                        case Win.WM_XBUTTONDOWN: Add(Ev.MDOWN, x, y, (HiWord(m.mouseData) == 2) ? Ev.BTN_X2 : Ev.BTN_X1); break;
                        case Win.WM_XBUTTONUP: Add(Ev.MUP, x, y, (HiWord(m.mouseData) == 2) ? Ev.BTN_X2 : Ev.BTN_X1); break;
                        case Win.WM_MOUSEWHEEL: Add(Ev.WHEEL, x, y, (short)HiWord(m.mouseData)); break;
                        case Win.WM_MOUSEHWHEEL: Add(Ev.HWHEEL, x, y, (short)HiWord(m.mouseData)); break;
                    }
                }
            }
            return Win.CallNextHookEx(hMouse, nCode, wParam, lParam);
        }

        private IntPtr KeyHook(int nCode, IntPtr wParam, IntPtr lParam)
        {
            if (nCode >= 0)
            {
                KBDLLHOOKSTRUCT k = (KBDLLHOOKSTRUCT)Marshal.PtrToStructure(lParam, typeof(KBDLLHOOKSTRUCT));
                int msg = wParam.ToInt32();
                bool down = (msg == Win.WM_KEYDOWN || msg == Win.WM_SYSKEYDOWN);
                bool injected = (k.flags & Win.LLKHF_INJECTED) != 0;
                int vk = (int)k.vkCode;

                if (!injected)
                {
                    // Steuertasten abfangen, damit sie nicht in der Aufnahme landen
                    if (vk == (int)Keys.F9)
                    {
                        if (down) BeginInvoke(new MethodInvoker(ToggleRecord));
                        return new IntPtr(1);
                    }
                    if (vk == (int)Keys.F10)
                    {
                        if (down) BeginInvoke(new MethodInvoker(TogglePlay));
                        return new IntPtr(1);
                    }
                    if (vk == (int)Keys.Escape && playing)
                    {
                        stopRequested = true;
                        return new IntPtr(1);
                    }

                    if (recording) Add(down ? Ev.KDOWN : Ev.KUP, 0, 0, vk);
                }
            }
            return Win.CallNextHookEx(hKey, nCode, wParam, lParam);
        }

        // ---------------- Aufnahme ----------------

        private void ToggleRecord()
        {
            if (playing) return;
            if (!recording)
            {
                events.Clear();
                recClock.Reset();
                recClock.Start();
                recording = true;
            }
            else
            {
                recording = false;
                recClock.Stop();
                Normalize();
            }
            UpdateUi();
        }

        // Leerlauf am Anfang abschneiden, damit eine Schleife sauber laeuft
        private void Normalize()
        {
            if (events.Count == 0) return;
            long first = events[0].T;
            for (int i = 0; i < events.Count; i++) events[i].T -= first;
        }

        private void ClearEvents()
        {
            if (recording || playing) return;
            events.Clear();
            UpdateUi();
        }

        // ---------------- Abspielen ----------------

        private void TogglePlay()
        {
            if (recording) return;
            if (playing) { stopRequested = true; return; }
            if (events.Count == 0)
            {
                MessageBox.Show(this, "Es ist noch nichts aufgenommen. Zuerst mit F9 aufnehmen oder ein Makro laden.",
                    "Makro-Rekorder", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            bool forever = rbForever.Checked;
            int reps = (int)numCount.Value;
            int pause = (int)numPause.Value;
            double speed = (double)numSpeed.Value;
            if (speed < 0.05) speed = 0.05;

            List<Ev> snapshot = new List<Ev>(events);

            stopRequested = false;
            playing = true;
            currentRep = 0;
            UpdateUi();

            playThread = new Thread(delegate()
            {
                try { PlayLoop(snapshot, forever, reps, pause, speed); }
                catch { }
                finally { playing = false; }
            });
            playThread.IsBackground = true;
            playThread.Start();
        }

        private void PlayLoop(List<Ev> list, bool forever, int reps, int pause, double speed)
        {
            RefreshScreenMetrics();
            HashSet<int> keysDown = new HashSet<int>();
            HashSet<int> btnsDown = new HashSet<int>();
            Stopwatch sw = new Stopwatch();

            try
            {
                for (int rep = 0; forever || rep < reps; rep++)
                {
                    if (stopRequested) break;
                    currentRep = rep + 1;
                    sw.Reset();
                    sw.Start();

                    for (int i = 0; i < list.Count; i++)
                    {
                        Ev e = list[i];
                        double target = e.T / speed;
                        while (true)
                        {
                            if (stopRequested) return;
                            double remaining = target - sw.Elapsed.TotalMilliseconds;
                            if (remaining <= 0.5) break;
                            Thread.Sleep(remaining > 8 ? 4 : 1);
                        }
                        if (stopRequested) return;
                        Send(e, keysDown, btnsDown);
                    }

                    if (stopRequested) break;

                    int waited = 0;
                    while (waited < pause)
                    {
                        if (stopRequested) return;
                        int chunk = Math.Min(20, pause - waited);
                        Thread.Sleep(chunk);
                        waited += chunk;
                    }
                }
            }
            finally
            {
                ReleaseAll(keysDown, btnsDown);
            }
        }

        // Haengengebliebene Tasten und Maustasten wieder loslassen
        private void ReleaseAll(HashSet<int> keysDown, HashSet<int> btnsDown)
        {
            foreach (int vk in keysDown) SendKey(vk, true);
            foreach (int b in btnsDown)
            {
                Point p = Cursor.Position;
                SendMouse(p.X, p.Y, UpFlag(b), XData(b));
            }
            keysDown.Clear();
            btnsDown.Clear();
        }

        private void Send(Ev e, HashSet<int> keysDown, HashSet<int> btnsDown)
        {
            switch (e.Type)
            {
                case Ev.MOVE:
                    SendMouse(e.X, e.Y, 0, 0);
                    break;
                case Ev.MDOWN:
                    btnsDown.Add(e.Data);
                    SendMouse(e.X, e.Y, DownFlag(e.Data), XData(e.Data));
                    break;
                case Ev.MUP:
                    btnsDown.Remove(e.Data);
                    SendMouse(e.X, e.Y, UpFlag(e.Data), XData(e.Data));
                    break;
                case Ev.WHEEL:
                    SendMouse(e.X, e.Y, Win.MOUSEEVENTF_WHEEL, unchecked((uint)e.Data));
                    break;
                case Ev.HWHEEL:
                    SendMouse(e.X, e.Y, Win.MOUSEEVENTF_HWHEEL, unchecked((uint)e.Data));
                    break;
                case Ev.KDOWN:
                    keysDown.Add(e.Data);
                    SendKey(e.Data, false);
                    break;
                case Ev.KUP:
                    keysDown.Remove(e.Data);
                    SendKey(e.Data, true);
                    break;
            }
        }

        private static uint DownFlag(int btn)
        {
            switch (btn)
            {
                case Ev.BTN_L: return Win.MOUSEEVENTF_LEFTDOWN;
                case Ev.BTN_R: return Win.MOUSEEVENTF_RIGHTDOWN;
                case Ev.BTN_M: return Win.MOUSEEVENTF_MIDDLEDOWN;
                default: return Win.MOUSEEVENTF_XDOWN;
            }
        }

        private static uint UpFlag(int btn)
        {
            switch (btn)
            {
                case Ev.BTN_L: return Win.MOUSEEVENTF_LEFTUP;
                case Ev.BTN_R: return Win.MOUSEEVENTF_RIGHTUP;
                case Ev.BTN_M: return Win.MOUSEEVENTF_MIDDLEUP;
                default: return Win.MOUSEEVENTF_XUP;
            }
        }

        private static uint XData(int btn)
        {
            if (btn == Ev.BTN_X1) return 1;
            if (btn == Ev.BTN_X2) return 2;
            return 0;
        }

        private static int vsX, vsY, vsW, vsH;

        private static void RefreshScreenMetrics()
        {
            vsX = Win.GetSystemMetrics(Win.SM_XVIRTUALSCREEN);
            vsY = Win.GetSystemMetrics(Win.SM_YVIRTUALSCREEN);
            vsW = Win.GetSystemMetrics(Win.SM_CXVIRTUALSCREEN);
            vsH = Win.GetSystemMetrics(Win.SM_CYVIRTUALSCREEN);
            if (vsW < 2) vsW = 2;
            if (vsH < 2) vsH = 2;
        }

        private static void SendMouse(int x, int y, uint flags, uint data)
        {
            INPUT[] inp = new INPUT[1];
            inp[0].type = 0; // INPUT_MOUSE
            inp[0].u.mi.dx = (int)Math.Round((double)(x - vsX) * 65535.0 / (double)(vsW - 1));
            inp[0].u.mi.dy = (int)Math.Round((double)(y - vsY) * 65535.0 / (double)(vsH - 1));
            inp[0].u.mi.mouseData = data;
            inp[0].u.mi.dwFlags = flags | Win.MOUSEEVENTF_MOVE | Win.MOUSEEVENTF_ABSOLUTE | Win.MOUSEEVENTF_VIRTUALDESK;
            inp[0].u.mi.time = 0;
            inp[0].u.mi.dwExtraInfo = IntPtr.Zero;
            Win.SendInput(1, inp, Marshal.SizeOf(typeof(INPUT)));
        }

        private static bool IsExtended(int vk)
        {
            switch (vk)
            {
                case 33: case 34: case 35: case 36:   // Bild auf, Bild ab, Ende, Pos1
                case 37: case 38: case 39: case 40:   // Pfeiltasten
                case 45: case 46:                     // Einfg, Entf
                case 91: case 92: case 93:            // Windows-Tasten, Menue
                case 111:                             // Numblock geteilt
                case 144:                             // Num-Lock
                case 163: case 165:                   // Strg rechts, Alt Gr
                case 44:                              // Druck
                    return true;
                default:
                    return false;
            }
        }

        private static void SendKey(int vk, bool up)
        {
            ushort scan = (ushort)Win.MapVirtualKey((uint)vk, 0);
            uint flags = up ? Win.KEYEVENTF_KEYUP : 0u;
            INPUT[] inp = new INPUT[1];
            inp[0].type = 1; // INPUT_KEYBOARD
            if (scan != 0)
            {
                inp[0].u.ki.wVk = 0;
                inp[0].u.ki.wScan = scan;
                flags |= Win.KEYEVENTF_SCANCODE;
            }
            else
            {
                inp[0].u.ki.wVk = (ushort)vk;
                inp[0].u.ki.wScan = 0;
            }
            if (IsExtended(vk)) flags |= Win.KEYEVENTF_EXTENDEDKEY;
            inp[0].u.ki.dwFlags = flags;
            inp[0].u.ki.time = 0;
            inp[0].u.ki.dwExtraInfo = IntPtr.Zero;
            Win.SendInput(1, inp, Marshal.SizeOf(typeof(INPUT)));
        }

        // ---------------- Speichern und Laden ----------------

        private void SaveMacro()
        {
            if (recording || playing) return;
            if (events.Count == 0)
            {
                MessageBox.Show(this, "Es ist nichts zum Speichern da.", "Makro-Rekorder");
                return;
            }
            SaveFileDialog d = new SaveFileDialog();
            d.Filter = "Makro (*.mkr)|*.mkr|Alle Dateien (*.*)|*.*";
            d.FileName = "makro.mkr";
            if (d.ShowDialog(this) != DialogResult.OK) return;
            try
            {
                using (StreamWriter w = new StreamWriter(d.FileName, false))
                {
                    w.WriteLine("MAKRO1");
                    foreach (Ev e in events)
                    {
                        w.WriteLine(
                            e.Type.ToString(CultureInfo.InvariantCulture) + ";" +
                            e.T.ToString(CultureInfo.InvariantCulture) + ";" +
                            e.X.ToString(CultureInfo.InvariantCulture) + ";" +
                            e.Y.ToString(CultureInfo.InvariantCulture) + ";" +
                            e.Data.ToString(CultureInfo.InvariantCulture));
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "Speichern fehlgeschlagen: " + ex.Message, "Makro-Rekorder");
            }
        }

        private void LoadMacro()
        {
            if (recording || playing) return;
            OpenFileDialog d = new OpenFileDialog();
            d.Filter = "Makro (*.mkr)|*.mkr|Alle Dateien (*.*)|*.*";
            if (d.ShowDialog(this) != DialogResult.OK) return;
            try
            {
                List<Ev> loaded = new List<Ev>();
                string[] lines = File.ReadAllLines(d.FileName);
                for (int i = 0; i < lines.Length; i++)
                {
                    string line = lines[i].Trim();
                    if (line.Length == 0 || line == "MAKRO1") continue;
                    string[] p = line.Split(';');
                    if (p.Length < 5) continue;
                    Ev e = new Ev();
                    e.Type = int.Parse(p[0], CultureInfo.InvariantCulture);
                    e.T = long.Parse(p[1], CultureInfo.InvariantCulture);
                    e.X = int.Parse(p[2], CultureInfo.InvariantCulture);
                    e.Y = int.Parse(p[3], CultureInfo.InvariantCulture);
                    e.Data = int.Parse(p[4], CultureInfo.InvariantCulture);
                    loaded.Add(e);
                }
                events = loaded;
                Normalize();
                UpdateUi();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "Laden fehlgeschlagen: " + ex.Message, "Makro-Rekorder");
            }
        }

        // ---------------- Oberflaeche aktualisieren ----------------

        private void UpdateUi()
        {
            if (recording)
            {
                lblStatus.Text = "Aufnahme laeuft ...";
                lblStatus.ForeColor = ACC;
                btnRec.Text = "Aufnahme stoppen  (F9)";
                btnRec.Enabled = true;
                btnPlay.Enabled = false;
            }
            else if (playing)
            {
                lblStatus.Text = rbForever.Checked
                    ? "Abspielen endlos - Durchlauf " + currentRep
                    : "Abspielen - Durchlauf " + currentRep + " von " + (int)numCount.Value;
                lblStatus.ForeColor = Color.FromArgb(95, 200, 125);
                btnPlay.Text = "Stoppen  (F10 / Esc)";
                btnPlay.Enabled = true;
                btnRec.Enabled = false;
            }
            else
            {
                lblStatus.Text = "Bereit";
                lblStatus.ForeColor = FG;
                btnRec.Text = "Aufnehmen  (F9)";
                btnPlay.Text = "Abspielen  (F10)";
                btnRec.Enabled = true;
                btnPlay.Enabled = true;
            }

            double secs = 0;
            if (events.Count > 0) secs = events[events.Count - 1].T / 1000.0;
            lblCount.Text = events.Count + " Schritte  |  Laenge " + secs.ToString("0.0", CultureInfo.InvariantCulture) + " s";

            bool idle = !recording && !playing;
            btnClear.Enabled = idle;
            btnSave.Enabled = idle;
            btnLoad.Enabled = idle;
            numCount.Enabled = idle;
            numPause.Enabled = idle;
            numSpeed.Enabled = idle;
            rbCount.Enabled = idle;
            rbForever.Enabled = idle;
            chkMoves.Enabled = idle;
        }
    }

    internal static class Program
    {
        [STAThread]
        private static void Main()
        {
            try { Win.SetProcessDPIAware(); }
            catch { }
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new MainForm());
        }
    }
}
